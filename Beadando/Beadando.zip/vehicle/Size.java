package vehicle;

public enum Size{
        SMALL,
        LARGE
    }